package org.example.stepDefs;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.messages.types.Hook;
import org.example.pages.P001_register;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.asserts.SoftAssert;

public class D001_register {
    P001_register register = new P001_register();
    Actions actions = new Actions(Hooks.driver);
    SoftAssert soft = new SoftAssert();
    @Given("user go to register page")
    public void userGoToRegisterPage() {
        register.close.click();
        register.login.click();
        register.loginBTN.click();
    }

    @When("user enter the mobile number")
    public void userEnterTheMobileNumber() {
        register.emailInput.sendKeys("mostafahesham10589@hotmail.com");
        register.submitContinue.click();

    }

    @And("user enter the password & confirm password")
    public void userEnterThePasswordConfirmPassword() throws InterruptedException {
        register.password.sendKeys("mostafahesham1058");
        register.confirmPassword.sendKeys("mostafahesham1058");
        Thread.sleep(1500);
        register.continueBtn.click();
    }

    @And("user enter first name & last name & email")
    public void userEnterFirstNameLastNameEmail() throws InterruptedException {
        register.firstName.sendKeys("mostafa");
        register.lastName.sendKeys("hehsmam");
        register.phone.sendKeys("01058741236");
        Thread.sleep(1500);
        register.continuebtn2.click();

    }

    @And("user choose the Gender & birthday & click on check box")
    public void userChooseTheGenderBirthdayClickOnCheckBox() throws InterruptedException {
        register.GenderDropList.click();
        register.GenderType.click();
        Thread.sleep(1500);
        register.birthDate.click();
        register.birthDate.sendKeys("09051995");
        register.checkBox.click();
        Thread.sleep(1500);
        register.contiuebtn3.click();

    }



}
