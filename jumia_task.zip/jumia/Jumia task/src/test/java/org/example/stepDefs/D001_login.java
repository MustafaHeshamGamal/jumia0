package org.example.stepDefs;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.example.pages.P001_login;
import org.openqa.selenium.interactions.Actions;
import org.testng.asserts.SoftAssert;

public class D001_login {
    P001_login login = new P001_login();
    Actions actions = new Actions(Hooks.driver);
    SoftAssert soft = new SoftAssert();
    String productname1;
    String productname2;
    @Given("user go to sign in page")
    public void userGoToSignInPage() throws InterruptedException {
                login.close.click();
        login.login.click();
        login.loginBTN.click();






    }

    @When("user enter valid mobil number :{string} and password: {string}")
    public void userEnterValidMobilNumberAndPassword(String arg0, String arg1) {
        login.emailInput.sendKeys("galaltorkey11@gmail.com");
        login.submitContinue.click();
        login.passInput.sendKeys("eV_8dJatN7yN4K*");

    }

    @And("click on login")
    public void clickOnLogin() {
        login.submitlogin.click();
    }

    @And("user hover on supermarket and click on bakery")
    public void userHoverOnSupermarketAndClickOnBakery() throws InterruptedException {
        Thread.sleep(2000);
        actions.moveToElement(login.supermarket).perform();
        login.bakery.click();
    }

    @And("user add two items to his cart")
    public void userAddTwoItemsToHisCart() throws InterruptedException {
         productname1 = login.product1.getText();
         productname2 = login.product2.getText();
        System.out.println(productname2);
        System.out.println(productname1);
        actions.moveToElement(login.product1).perform();
        login.addtocart1.click();
        login.closecart.click();
        Thread.sleep(2000);
        actions.moveToElement(login.product2).perform();
        login.addtocart2.click();
        login.closecart.click();
        Thread.sleep(1000);
    }

    @And("user verify that the item is added to the cart successfully")
    public void userVerifyThatTheItemIsAddedToTheCartSuccessfully() throws InterruptedException {
        login.cart.click();
        Thread.sleep(1000);
        soft.assertEquals(login.productCart1.getText(),productname1);
        soft.assertEquals(login.productCart2.getText(),productname2);

    }

    @Then("user Verify that the subtotal is calculated correctly")
    public void userVerifyThatTheSubtotalIsCalculatedCorrectly() {
        double price1 = Double.parseDouble(login.price1.getText().replaceAll("[A-Za-z ]",""));
        double price2 = Double.parseDouble(login.price2.getText().replaceAll("[A-Za-z ]",""));
        System.out.println(price1);
        System.out.println(price2);
        double total = Double.parseDouble(login.totalamount.getText().replaceAll("[A-Za-z ]",""));
        soft.assertEquals(total,price2+price1);
    }
}
