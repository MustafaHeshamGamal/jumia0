package org.example.pages;

import org.example.stepDefs.Hooks;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.devtools.v85.page.Page;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class P001_register {
 public P001_register(){
     PageFactory.initElements(Hooks.driver,this);
 }
@FindBy(css = "button[aria-label=\"newsletter_popup_close-cta\"]")
    public WebElement close;
 @FindBy(css = "label[for=\"dpdw-login\"]")
    public WebElement login;
 @FindBy(css = "a[href=\"/customer/account/login/?return=%2F\"]")
    public WebElement loginBTN;
 @FindBy(id = "input_identifierValue")
    public WebElement emailInput;
 @FindBy(name = "password")
    public WebElement passInput;
 @FindBy(id = "loginButton")
    public WebElement submitlogin;
 @FindBy(css = "button[type=\"submit\"]")
    public WebElement submitContinue;
 @FindBy(css = "a[href=\"/groceries/\"]")
    public WebElement supermarket;
 @FindBy(css = "a[href=\"/breads-bakery/\"]")
    public WebElement bakery;
 @FindBy(css = "div[data-catalog=\"true\"] article:nth-child(1) button[type=\"button\"]")
    public WebElement addtocart1;
    @FindBy(css = "div[data-catalog=\"true\"] article:nth-child(1) h3")
    public WebElement product1;
    @FindBy(css = "div[data-catalog=\"true\"] article:nth-child(2) button[type=\"button\"]")
    public WebElement addtocart2;
    @FindBy(css = "div[data-catalog=\"true\"] article:nth-child(2) h3")
    public WebElement product2;
@FindBy(css = "a[href=\"/cart/\"]")
    public WebElement cart;
@FindBy(css = "article[class=\"card -mtm\"] article:nth-of-type(1) h3")
    public WebElement productCart1;
    @FindBy(css = "article[class=\"card -mtm\"] article:nth-of-type(2) h3")
    public WebElement productCart2;
    @FindBy(css = "article[class=\"card -mtm\"] article:nth-of-type(1) div[class=\"prc\"]")
    public WebElement price1;
    @FindBy(css = "article[class=\"card -mtm\"] article:nth-of-type(2) div[class=\"prc\"]")
    public WebElement price2;
    @FindBy(css = "button[class=\"close\"]")
    public WebElement closecart;
    @FindBy(css = "p[class=\"-fs20 -plm -tar\"]")
    public WebElement totalamount;

    // this is for register

    @FindBy(css = "input[name=\"password\"]")
    public WebElement password;
    @FindBy(css = "input[autocomplete=\"confirm-password\"]")
    public WebElement confirmPassword;
    @FindBy(css = "#card_password span[class=\"mdc-button__touch\"]")
    public WebElement continueBtn;
    @FindBy(css = "input[name=\"first_name\"]")
    public WebElement firstName;
    @FindBy(css = "input[name=\"last_name\"]")
    public WebElement lastName;
    @FindBy(name = "phone[number]")
    public WebElement phone;
    @FindBy(css = "#card_profile_details span[class=\"mdc-button__touch\"]")
    public WebElement continuebtn2;
    @FindBy(css = "#card_profile_gender div[class=\"mdc-select__anchor\"]")
    public WebElement GenderDropList;
        @FindBy(css = "li[data-value=\"M\"]")
    public WebElement GenderType;
    @FindBy(css = "label[class=\"mdc-text-field--ltr-text mdc-text-field mdc-text-field--outlined mdc-text-field--with-trailing-icon text-field mdc-text-field--label-floating mdc-text-field--invalid\"]")
    public WebElement birthDate;
    @FindBy(css = "input[type=\"checkbox\"]")
    public WebElement checkBox;
    @FindBy(css = "#card_profile_gender span[class=\"mdc-button__touch\"]")
    public WebElement contiuebtn3;




}
