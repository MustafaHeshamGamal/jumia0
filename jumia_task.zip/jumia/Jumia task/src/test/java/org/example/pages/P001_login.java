package org.example.pages;

import org.example.stepDefs.Hooks;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class P001_login {
    public P001_login(){
        PageFactory.initElements(Hooks.driver,this);
    }
    @FindBy(css = "button[aria-label=\"newsletter_popup_close-cta\"]")
    public WebElement close;
    @FindBy(css = "label[for=\"dpdw-login\"]")
    public WebElement login;
    @FindBy(css = "a[href=\"/customer/account/login/?return=%2F\"]")
    public WebElement loginBTN;
    @FindBy(id = "input_identifierValue")
    public WebElement emailInput;
    @FindBy(name = "password")
    public WebElement passInput;
    @FindBy(id = "loginButton")
    public WebElement submitlogin;
    @FindBy(css = "button[type=\"submit\"]")
    public WebElement submitContinue;
    @FindBy(css = "a[href=\"/groceries/\"]")
    public WebElement supermarket;
    @FindBy(css = "a[href=\"/breads-bakery/\"]")
    public WebElement bakery;
    @FindBy(css = "div[data-catalog=\"true\"] article:nth-child(1) button[type=\"button\"]")
    public WebElement addtocart1;
    @FindBy(css = "div[data-catalog=\"true\"] article:nth-child(1) h3")
    public WebElement product1;
    @FindBy(css = "div[data-catalog=\"true\"] article:nth-child(2) button[type=\"button\"]")
    public WebElement addtocart2;
    @FindBy(css = "div[data-catalog=\"true\"] article:nth-child(2) h3")
    public WebElement product2;
    @FindBy(css = "a[href=\"/cart/\"]")
    public WebElement cart;
    @FindBy(css = "article[class=\"card -mtm\"] article:nth-of-type(1) h3")
    public WebElement productCart1;
    @FindBy(css = "article[class=\"card -mtm\"] article:nth-of-type(2) h3")
    public WebElement productCart2;
    @FindBy(css = "article[class=\"card -mtm\"] article:nth-of-type(1) div[class=\"prc\"]")
    public WebElement price1;
    @FindBy(css = "article[class=\"card -mtm\"] article:nth-of-type(2) div[class=\"prc\"]")
    public WebElement price2;
    @FindBy(css = "button[class=\"close\"]")
    public WebElement closecart;
    @FindBy(css = "p[class=\"-fs20 -plm -tar\"]")
    public WebElement totalamount;

}
